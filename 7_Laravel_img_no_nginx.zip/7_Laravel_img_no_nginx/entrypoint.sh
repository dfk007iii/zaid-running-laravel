#!/bin/bash
# Start PHP-FPM service
mongod --fork --logpath /var/log/mongodb/mongod.log
service php8.2-fpm start
cd /var/www/html/laravel-app
php artisan serve --host=0.0.0.0 --port=8000
tail -f /dev/null

