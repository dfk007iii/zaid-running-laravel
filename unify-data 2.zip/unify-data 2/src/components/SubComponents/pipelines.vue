<template>
    <div><h1>this is pipeline</h1></div>
    </template>
    
    <script>
    </script>
    
    
    <style>
    </style>