<template>
    <div><h1>this is ai connector</h1></div>
    </template>
    
    <script>
    </script>
    
    
    <style>
    </style>