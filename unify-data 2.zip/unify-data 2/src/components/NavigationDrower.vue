<template>
    <v-navigation-drawer app v-model="drawer" :rail="rail" permanent @click="handleDrawerClick">
        <v-list density="compact" nav>
            <v-list-item prepend-avatar="/Users/mnouman/Desktop/unify-data/src/assets/logo.png" class="logo">
                <v-item-title class="custom-title">Unify Data</v-item-title>
                <template v-slot:append>
                    <v-icon style="font-size: 24px;" @click.stop="toggleRail">{{ rail ? 'mdi-chevron-right' : 'mdi-chevron-left' }}</v-icon>
                </template>
            </v-list-item>
            <v-divider></v-divider>
            <v-list-item
                v-for="item in dashboardItems"
                :key="item.value"
                :prepend-icon="item.icon"
                :title="item.title"
                :value="item.value"
                :active="selectedItem === item.value"
                :class="{'custom-list-item': true, 'selected-item': selectedItem === item.value}"
                @click="handleItemClick(item)"
            ></v-list-item>
        </v-list>

        <template v-slot:append>
            <v-list-item
                v-for="item in appendItems"
                :key="item.value"
                :prepend-icon="item.icon"
                :title="item.title"
                :value="item.value"
                :active="selectedItem === item.value"
                :class="{'custom-list-item': true, 'selected-item': selectedItem === item.value}"
                @click="handleItemClick(item)"
            ></v-list-item>
            <v-divider></v-divider>
            <Profile/>
        </template>
    </v-navigation-drawer>
</template>

<script>
import Profile from './Profile.vue';

export default {
    data() {
        return {
            drawer: true,
            selectedItem: null,
            rail: true,
            dashboardItems: [
                { route: '/dashboard', value: 'dashboard', icon: 'mdi-view-dashboard', title: 'Dashboard' },
                { route: '/pipelines', value: 'pipeline', icon: 'mdi-pipe', title: 'Pipelines' },
                { route: '/source', value: 'source', icon: 'mdi-power-plug', title: 'Source' },
                { route: '/transformation', value: 'transformation', icon: 'mdi-swap-horizontal-variant', title: 'Transformation' },
                { route: '/destination', value: 'destination', icon: 'mdi-map-marker-circle', title: 'Destination' },
                { route: '/build-ai-connection', value: 'build-ai-connection', icon: 'mdi-connection', title: 'Builder' },
                { route: '/FileInstructions', value: 'FileInstructions', icon: 'mdi-text-box-multiple-outline', title: 'File Instructions' }
            ],
            appendItems: [
                { route: '/help', value: 'help', icon: 'mdi-help-circle-outline', title: 'Help' },
                { route: '/workspace', value: 'workspace', icon: 'mdi-folder-network-outline', title: 'Workspace' },
            ]
        };
    },
    methods: {
        handleDrawerClick() {
            this.rail = false; // Close rail on any click inside the drawer
        },
        toggleRail() {
            this.rail = !this.rail;
        },
        handleItemClick(item) {
            console.log(`Item clicked: ${item.value}`);
            this.selectedItem = item.value;
            this.$router.push(item.route);  // Navigate to the route
        }
    }
};
</script>

<style scoped>


.custom-list-item:hover {
    background-color: #e0e0e0;
    color: #023C83;
    font-size: 20px;
}

.custom-title {
    font-size: 18px;
    color: #023C83;
    font-weight: bold;
}

.logo {
    font-size: 20px;
    height: 7vh;
}

.v-navigation-drawer {
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.v-icon {
    transition: transform 0.3s ease;
}
</style>
